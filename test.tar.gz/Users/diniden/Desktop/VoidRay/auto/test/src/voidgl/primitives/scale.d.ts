export interface IScale {
    x?: number;
    y?: number;
    z?: number;
}
