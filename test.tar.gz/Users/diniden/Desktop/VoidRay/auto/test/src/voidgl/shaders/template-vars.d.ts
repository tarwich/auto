export declare const templateVars: {
    attributes: string;
    easingMethod: string;
    extend: string;
    extendHeader: string;
    T: string;
};
