export declare type Image = {
    path?: string;
    element?: HTMLImageElement;
};
