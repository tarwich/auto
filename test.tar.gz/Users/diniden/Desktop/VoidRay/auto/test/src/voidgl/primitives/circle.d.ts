import { Vec2 } from "../util";
export declare type Circle = {
    center: Vec2;
    radius: number;
};
