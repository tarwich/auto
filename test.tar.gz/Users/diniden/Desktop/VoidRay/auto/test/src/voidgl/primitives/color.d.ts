export declare type Color = {
    r: number;
    g: number;
    b: number;
    opacity: number;
};
