import { IMaterialOptions } from "../types";
export declare class CommonMaterialOptions {
    static transparentShape: IMaterialOptions;
    static transparentImage: IMaterialOptions;
}
