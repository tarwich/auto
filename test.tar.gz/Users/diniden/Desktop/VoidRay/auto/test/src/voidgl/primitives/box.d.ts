export declare type Box = {
    height: number;
    width: number;
    x: number;
    y: number;
};
