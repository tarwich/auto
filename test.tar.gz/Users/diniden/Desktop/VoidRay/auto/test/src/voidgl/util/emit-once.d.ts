export declare function emitOnce(id: string, callback: (calledCountBeforeEmit: number, id: string) => void): void;
export declare function flushEmitOnce(): void;
