import { IInstanceAttribute } from "../../types";
import { Instance } from "../../util";
export declare function packAttributes<T extends Instance>(attributes: IInstanceAttribute<T>[]): void;
