import { Image } from "../../primitives/image";
import { BaseAtlasResource } from "./base-atlas-resource";
export declare class ImageAtlasResource extends BaseAtlasResource {
    image: Image;
    constructor(image: Image);
}
