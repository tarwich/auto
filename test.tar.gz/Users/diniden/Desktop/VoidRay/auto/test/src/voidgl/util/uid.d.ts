export declare function uid(): number;
export declare function colorUID(): number;
